﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asociacion
{
    internal class Test
    {
        static void Main(string[] args)
        {
            Departamento departamento1 = new Departamento(1,"Publico");
            Departamento departamento2 = new Departamento(2, "Privado");
            DateTime nacimiento1 = DateTime.Now;
            DateTime nacimiento2 = new DateTime(2008, 3, 1, 7, 0, 0);
            Jefe jefe1 = new Jefe(1, "Pablo", "Juan Todesco", 12345, nacimiento1);
            Jefe jefe2 = new Jefe(2, "Joaquin", "Paramos 123", 67890, nacimiento2);
            Empleado empleado1 = new Empleado(1, "Ramon", "Saltos 34", 111, "ramon@email.com", departamento1, jefe1);
            Empleado empleado2 = new Empleado(2, "Solivan", "Avellanos 33", 222, "solivan@email.com", departamento1, jefe1);
            Empleado empleado3 = new Empleado(3, "Martin", "Patriotas 883", 333, "martin@email.com", departamento2, jefe2);

            Console.WriteLine(empleado1.ToString());
            Console.WriteLine("--------------------");
            Console.WriteLine(empleado2.ToString());
            Console.WriteLine("--------------------");
            Console.WriteLine(empleado3.ToString());
            Console.WriteLine("--------------------");
        }
    }
}
