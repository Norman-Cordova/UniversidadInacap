﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asociacion
{
    internal class Departamento
    {
        public int Id { get; set; }
        public string Nombre { get; set; }

        public Departamento(int id, string nombre)
        {
            Id = id;
            Nombre = nombre;
        }

        public override bool Equals(object obj)
        {
            return obj is Departamento departamento &&
                   Id == departamento.Id &&
                   Nombre == departamento.Nombre;
        }

        public override int GetHashCode()
        {
            int hashCode = -1675956928;
            hashCode = hashCode * -1521134295 + Id.GetHashCode();
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Nombre);
            return hashCode;
        }

        public override string ToString()
        {
            return string.Format("Id: "+ this.Id + "\n" + "Nombre: " + this.Nombre + "\n");
        }
    }
}
