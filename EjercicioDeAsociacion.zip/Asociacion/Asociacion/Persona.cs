﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asociacion
{
    internal class Persona
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public int Fono { get; set; }

        public Persona(int id, string nombre, string direccion, int fono)
        {
            Id = id;
            Nombre = nombre;
            Direccion = direccion;
            Fono = fono;
        }

        public override bool Equals(object obj)
        {
            return obj is Persona persona &&
                   Id == persona.Id &&
                   Nombre == persona.Nombre &&
                   Direccion == persona.Direccion &&
                   Fono == persona.Fono;
        }

        public override int GetHashCode()
        {
            int hashCode = -1741114926;
            hashCode = hashCode * -1521134295 + Id.GetHashCode();
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Nombre);
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Direccion);
            hashCode = hashCode * -1521134295 + Fono.GetHashCode();
            return hashCode;
        }

        public override string ToString()
        {
            return string.Format("Id: "+ this.Id + "\n" +
                "Nombre: " + this.Nombre + "\n" +
                "Direccion: " + this.Direccion + "\n" + 
                "Fono: " + this.Fono + "\n");
        }
    }
}
