﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asociacion
{
    internal class Empleado : Persona
    {
        public string Email { get; set; }
        public Departamento Departamento { get; set; }
        public Jefe Jefe { get; set; }
        public Empleado(int id, string nombre, string direccion, int fono, string email, Departamento departamento, Jefe jefe) : base(id, nombre, direccion, fono)
        {
            Email = email;
            Departamento = departamento;
            Jefe = jefe;
        }

        public override bool Equals(object obj)
        {
            return obj is Empleado empleado &&
                   base.Equals(obj) &&
                   Id == empleado.Id &&
                   Nombre == empleado.Nombre &&
                   Direccion == empleado.Direccion &&
                   Fono == empleado.Fono &&
                   Email == empleado.Email &&
                   EqualityComparer<Departamento>.Default.Equals(Departamento, empleado.Departamento) &&
                   EqualityComparer<Jefe>.Default.Equals(Jefe, empleado.Jefe);
        }

        public override int GetHashCode()
        {
            int hashCode = -1246258897;
            hashCode = hashCode * -1521134295 + base.GetHashCode();
            hashCode = hashCode * -1521134295 + Id.GetHashCode();
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Nombre);
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Direccion);
            hashCode = hashCode * -1521134295 + Fono.GetHashCode();
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Email);
            hashCode = hashCode * -1521134295 + EqualityComparer<Departamento>.Default.GetHashCode(Departamento);
            hashCode = hashCode * -1521134295 + EqualityComparer<Jefe>.Default.GetHashCode(Jefe);
            return hashCode;
        }

        public override string ToString()   
        {
            return base.ToString() +
                "Email: " + this.Email + "\n" +
                "Departamento: " + this.Departamento + 
                "\n" + "Jefe: " + this.Jefe + "\n";
        }
    }
}
