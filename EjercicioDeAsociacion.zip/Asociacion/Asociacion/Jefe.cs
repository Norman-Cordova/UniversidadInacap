﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asociacion
{
    internal class Jefe : Persona
    {
        public DateTime Nacimiento { get; set; }
        public Jefe(int id, string nombre, string direccion, int fono, DateTime nacimiento) : base(id, nombre, direccion, fono)
        {
            this.Nacimiento = nacimiento;
        }

        public override bool Equals(object obj)
        {
            return obj is Jefe jefe &&
                   base.Equals(obj) &&
                   Id == jefe.Id &&
                   Nombre == jefe.Nombre &&
                   Direccion == jefe.Direccion &&
                   Fono == jefe.Fono &&
                   Nacimiento == jefe.Nacimiento;
        }

        public override int GetHashCode()
        {
            int hashCode = 1304811104;
            hashCode = hashCode * -1521134295 + base.GetHashCode();
            hashCode = hashCode * -1521134295 + Id.GetHashCode();
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Nombre);
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Direccion);
            hashCode = hashCode * -1521134295 + Fono.GetHashCode();
            hashCode = hashCode * -1521134295 + Nacimiento.GetHashCode();
            return hashCode;
        }

        public override string ToString()
        {
            return base.ToString() + "Nacimento: "+ this.Nacimiento;
        }
    }
}
